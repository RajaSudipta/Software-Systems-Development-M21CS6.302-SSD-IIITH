var http = require('http');
var url = require('url');
var service = require('./service.js');

var port = 8080;

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'application/json'});

    let param = url.parse(req.url, true).query;
    let query = param.query;

    if(query == 1)
    {
        let response = service.getHighestMarks();
        res.write(JSON.stringify(response));
    }
    else if(query == 2)
    {
        let index = param.index;
        if(index >= 0)
        {
            let response = service.getSubjectiToppers(index);
            res.write(JSON.stringify(response));
        }
        else
        {
            res.write("Invalid query");
        }
    }
    else
    {
        res.write("Invalid query");
    }
    return res.end();

  }).listen(port, () => {
    console.log("Server is now listening on port: " + port);
  });