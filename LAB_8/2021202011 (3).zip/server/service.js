var files = require('fs');
var url = require('url');
var response;

files.readFile('./data.json',"utf-8", function(err, data) {
    
    response = JSON.parse(data);
    
    if(err){
        console.log("Error: ", err);
    }
});

function comp(x, y){
    return x.marks - y.marks;
}

exports.getHighestMarks = () => {
    let sum = 0;
    let max = 0;
    let student;
    for(let key in response)
    {
        sum = 0;
        let marks = response[key];

        marks.forEach(mk => {
            sum = sum + mk;
        });

        if(sum > max)
        {
            student = key;
            max = sum;
        }
    }

    return student;
}

exports.getSubjectiToppers = (index) => {

    let resultant_arr = [];
    let responseArray = [];

    for(let key in response) {
        let object = {
            'name' : key,
            'marks' : response[key][index]
        };
        responseArray.push(object);
    }

    responseArray.sort(comp);
    
    for(let object of responseArray){
        let temp = [ object.name, object.marks ];
        resultant_arr.push(temp);
    }

    return resultant_arr;
}


// responseArray = responseArray.sort((a,b) => a.marks - b.marks);
