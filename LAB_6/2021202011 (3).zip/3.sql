-- Output – Manager ssn, Number of projects

USE `COMPANY`;
SELECT Essn as 'Manager ssn', COUNT(*) as 'Number of projects' FROM WORKS_ON WHERE Essn in ( 
    SELECT Mgr_ssn FROM DEPARTMENT WHERE Dnumber in (
    SELECT Dnum FROM PROJECT WHERE Pname = 'ProductY') GROUP BY Mgr_ssn);
