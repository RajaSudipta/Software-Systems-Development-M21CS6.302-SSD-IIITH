-- Output – Dept. Id, Dept. Name, Number of locations

USE `COMPANY`;
SELECT dept.Dnumber as 'Dept. Id', dept.Dname as 'Dept. Name', count(loc.Dlocation) as 'Number of locations'
FROM DEPT_LOCATIONS loc, DEPARTMENT dept
WHERE loc.Dnumber=dept.Dnumber and dept.Mgr_ssn IN(
    SELECT dnt.Essn
    FROM DEPENDENT dnt
    WHERE dnt.Sex='F'
    GROUP BY dnt.Essn
    HAVING count(*)>1
)
GROUP BY loc.Dnumber;