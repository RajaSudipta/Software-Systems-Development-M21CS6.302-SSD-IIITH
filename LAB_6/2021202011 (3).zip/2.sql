-- Output – Full name, ssn, Number of employees

USE `COMPANY`;
SELECT CONCAT(emp2.Fname,' ',emp2.Minit,' ', emp2.Lname) as 'Full name', emp2.Ssn as 'ssn', dept.Dname as 'Department Name', count(*) as 'Number of employees'
FROM DEPARTMENT dept, EMPLOYEE emp1, EMPLOYEE emp2 
WHERE emp1.Super_ssn=emp2.Ssn AND emp2.Dno=dept.Dnumber
GROUP BY emp2.Ssn
ORDER BY count(emp2.Ssn);