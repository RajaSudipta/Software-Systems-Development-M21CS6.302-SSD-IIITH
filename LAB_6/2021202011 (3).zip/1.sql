-- Output – Full name, ssn, Dept. Id, Dept. Name

USE `COMPANY`;
SELECT 
  concat(emp.Fname,' ',emp.Minit,' ',emp.Lname) as 'Full name',
  emp.Ssn as 'ssn',
  dept.DNumber as 'Dept. Id',
  dept.Dname as 'Dept. Name'
FROM DEPARTMENT AS dept, EMPLOYEE AS emp
  WHERE dept.Mgr_ssn = emp.Ssn AND dept.DNumber in 
  (SELECT DISTINCT prj.Dnum 
    FROM PROJECT AS prj,
    WORKS_ON as wrk
    WHERE prj.Pnumber = wrk.Pno
    GROUP BY prj.Dnum, wrk.Essn
    HAVING sum(Hours) < 40);