-- Output – Manager ssn, Dept. Id, Number of Dependents

USE `COMPANY`;
select dnt.Essn as 'Manager ssn', dept.Dnumber as 'Dept. Id', count(*) as 'Number of Dependents'
from DEPARTMENT dept, DEPENDENT dnt
where dnt.Essn=dept.Mgr_ssn
group by dnt.Essn,dept.Dnumber
having dnt.Essn in (select dept.Mgr_ssn
from DEPARTMENT dept
where dept.Dnumber = (select Dnumber from DEPT_LOCATIONS group by Dnumber having count(*) >= 2) );