# SSD ASSIGNMENT 3B
## 1. First of all create a database named 'chef'. I have used xaamp here in my local machine
## 2. The tables will be created automatically at the beginning of the program.
## 3. A chef account will be created at the beginning of the program 'chef:chef@123'
## 4. A user account will be created at the beginning of the program 'user:123'
## 5. All two preloaded users are logged out at the beginning
## 6. I have assumed that the Menu will be loaded into the food_menu table from Menu.csv for initial requirement
