
from flask import Flask, request, session, jsonify
from flask_restful import Api, Resource
from flask_login import LoginManager, UserMixin
from flask import Flask, render_template, flash, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_session import Session
import csv
import json
import pymysql

from requests.sessions import default_hooks
pymysql.install_as_MySQLdb()


#create the object of Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'hardsecretkey'

#SqlAlchemy Database Configuration With Mysql
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:''@localhost/chef'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
api = Api(app)

db = SQLAlchemy(app)

#our model
class UserInfo(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    isLoggedIn = db.Column(db.Boolean, default=False, nullable=False)
    isChef = db.Column(db.Boolean, default=False, nullable=False)

    def __init__(self, username, password, isLoggedIn, isChef):
        self.username = username
        self.password = password
        self.isLoggedIn = isLoggedIn
        self.isChef = isChef


class FoodMenu(UserMixin, db.Model):
    # id = db.Column(db.Integer, primary_key=True)
    # item_no = db.Column(db.Integer, unique=True)
    item_no = db.Column(db.Integer, primary_key=True)
    half_plate_cost = db.Column(db.Integer, default=0, nullable=False)
    full_plate_cost = db.Column(db.Integer, default=0, nullable=False)

    def __init__(self, item_no, half_plate_cost, full_plate_cost):
        self.item_no = item_no
        self.half_plate_cost = half_plate_cost
        self.full_plate_cost = full_plate_cost


class Transaction(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    order_history = db.Column(db.String(500), default='', nullable=False)
    tip_in_percentage = db.Column(db.Integer, default=0, nullable=False)
    lottery_amount = db.Column(db.Float, default=0.0, nullable=False)
    final_total_cost = db.Column(db.Float, default=0.0, nullable=False)
    contributors = db.Column(db.Integer, default=1, nullable=False)
    share_per_person = db.Column(db.Float)
    initial_cost = db.Column(db.Float, default=0.0, nullable=False)

    def __init__(self, username, order_history, tip_in_percentage, lottery_amount, final_total_cost, contributors, share_per_person, initial_cost):
        self.username = username
        self.order_history = order_history
        self.tip_in_percentage = tip_in_percentage
        self.lottery_amount = lottery_amount
        self.final_total_cost = final_total_cost
        self.contributors = contributors
        self.share_per_person = share_per_person
        self.initial_cost = initial_cost


class SignUp(Resource):
    def post(self):
        retrieved_data = request.get_json()
        user_name = retrieved_data['user_name']
        password = retrieved_data['password']
        role = retrieved_data['role']
        # print("role: ", end="")
        # print(role)
        # check if id already exist
        check = UserInfo.query.filter_by(username=user_name).first()
        if check is not None:
            returnJson = {
                "response": "id already exists."
            }
            return returnJson
        # if id already doesn't exist. create id
        else:
            temp = 'chef'
            if role.casefold() == temp.casefold():
                obj = UserInfo(username=user_name, password=password,
                               isLoggedIn=False, isChef=True)
            else:
                obj = UserInfo(username=user_name, password=password,
                           isLoggedIn = False, isChef=False)
            db.session.add(obj)
            db.session.commit()
            returnJson = {
                "response": "added successfully."
            }
            return returnJson


class LogIn(Resource):
    def post(self):
        retrieved_data = request.get_json()
        user_name = retrieved_data['user_name']
        password = retrieved_data['password']

        check = UserInfo.query.filter_by(username=user_name).first()
        if check:
            if check.password == password:
                session['loggedin'] = True
                session['username'] = user_name
                # print(session['username'])
                check.isLoggedIn = True
                db.session.commit()
                returnJson = {
                    "response": "Successfully Logged In!!"
                }
                return returnJson
            else:
                returnJson = {
                    "response": "UserName and Password does not match."
                }
                return returnJson
        else:
            returnJson = {
                "response": "UserName does not exist."
            }
            return returnJson


class LogOut(Resource):
    def post(self):
        retrieved_data = request.get_json()
        user_name = retrieved_data['user_name']
        check = UserInfo.query.filter_by(username=user_name).first()
        if check:
            if check.isLoggedIn == True:
                check.isLoggedIn = False
                db.session.commit()
                returnJson = {
                    "response": "Logged Out successfully."
                }
                return returnJson
            else:
                returnJson = {
                    "response": "UserName not Logged In."
                }
                return returnJson
        else:
            returnJson = {
                "response": "UserName does not exist."
            }
            return returnJson


class ReadLatestMenu(Resource):
    def get(self):
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='',
            db='chef',
        )

        cur = conn.cursor()
        cur.execute("SELECT * FROM food_menu")
        output = cur.fetchall()
        food_menu_2d_list = []
        for row in output:
            temp = []
            temp.append(int(row[0]))
            temp.append(int(row[1]))
            temp.append(int(row[2]))
            food_menu_2d_list.append(temp)
            # print(row[0])
            # print(row[1])
            # print(row[2])
            # print(row)
            #print("\n")
        # print(food_menu_2d_list)
        return food_menu_2d_list

# incomplete in server and client side
class OrderFoodItems(Resource):
    def post(self):
        retrieved_data = request
        print(retrieved_data)


class AddNewItems(Resource):
    def post(self):
        retrieved_data = request.get_json()
        user_name = retrieved_data['user_name']
        item_no = retrieved_data['item_no']
        half_plate_cost = retrieved_data['half_plate_cost']
        full_plate_cost = retrieved_data['full_plate_cost']
        check = UserInfo.query.filter_by(username=user_name).first()
        if check:
            if check.isChef == True:
                if check.isLoggedIn == True:
                    obj = FoodMenu(item_no=item_no,
                                half_plate_cost=half_plate_cost, full_plate_cost=full_plate_cost)
                    db.session.add(obj)
                    db.session.commit()
                    returnJson = {
                        "response": "Addition Successfull!!"
                    }
                    return returnJson
                else:
                    returnJson = {
                        "response": "You need to be logged in!!"
                    }
                    return returnJson
            else:
                returnJson = {
                    "response": "You are not a chef. Access Denied!!"
                }
                return returnJson
        else:
            returnJson = {
                "response": "UserName does not exist."
            }
            return returnJson


class ChcekUserExistsLoggedIn(Resource):
    def post(self):
        retrieved_data = request.get_json()
        user_name = retrieved_data['user_name']
        check = UserInfo.query.filter_by(username=user_name).first()
        if check:
            if check.isLoggedIn == True:
                returnJson = {
                    "response": "User Logged In."
                }
                return returnJson
            else:
                returnJson = {
                    "response": "User not Logged In."
                }
                return returnJson
        else:
            returnJson = {
                "response": "UserName does not exist."
            }
            return returnJson


class AddCompletedTransaction(Resource):
    def post(self):
        # json = {'user_name': user_name, 'order_history': order_history, 'tip_in_percentage': tip, 'lottery_amount': increaseOrDiscount, 'final_total_cost': updated_total_amount, 'contributors': heads, 'share_per_person': updated_per_head_amount})
        retrieved_data = request.get_json()
        user_name = retrieved_data['user_name']
        order_history = retrieved_data['order_history']
        tip_in_percentage = retrieved_data['tip_in_percentage']
        lottery_amount = retrieved_data['lottery_amount']
        final_total_cost = retrieved_data['final_total_cost']
        contributors = retrieved_data['contributors']
        share_per_person = retrieved_data['share_per_person']
        initial_cost = retrieved_data['initial_cost']

        obj = Transaction(username=user_name, order_history=order_history,
                          tip_in_percentage=tip_in_percentage, lottery_amount=lottery_amount,
                          final_total_cost=final_total_cost, contributors=contributors,
                          share_per_person=share_per_person, initial_cost=initial_cost)
        db.session.add(obj)
        db.session.commit()
        returnJson = {
            "response": "Transaction commited to database successfully."
        }
        return returnJson


class ListPreviousTransactions(Resource):
    def post(self):
        # json = {'user_name': user_name, 'order_history': order_history, 'tip_in_percentage': tip, 'lottery_amount': increaseOrDiscount, 'final_total_cost': updated_total_amount, 'contributors': heads, 'share_per_person': updated_per_head_amount})
        retrieved_data = request.get_json()
        user_name = retrieved_data['user_name']
        check = UserInfo.query.filter_by(username=user_name).first()
        if check:
            if check.isLoggedIn == True:
                conn = pymysql.connect(
                    host='localhost',
                    user='root',
                    password='',
                    db='chef',
                )

                cur = conn.cursor()
                query = ("SELECT * FROM transaction WHERE username=%s")
                cur.execute(query, (user_name))
                output = cur.fetchall()
                print(output)
                transaction_list = []
                for row in output:
                    temp = []
                    temp.append(int(row[0]))
                    temp.append(str(row[1]))
                    temp.append(str(row[2]))
                    temp.append(int(row[3]))
                    temp.append(float(row[4]))
                    temp.append(float(row[5]))
                    temp.append(int(row[6]))
                    temp.append(float(row[7]))
                    temp.append(float(row[8]))
                    transaction_list.append(temp)
                    # print(row[0], end=" ")
                    # print(row[1], end=" ")
                    # print(row[2], end=" ")
                    # print(row[3], end=" ")
                    # print(row[4], end=" ")
                    # print(row[5], end=" ")
                    # print(row[6], end=" ")
                    # print(row[7], end=" ")
                    # print("\n")
                return transaction_list
            else:
                tmp = []
                return tmp
        else:
            tmp = []
            return tmp



''' Adding the resource endpoints '''
api.add_resource(SignUp, '/sign_up')
api.add_resource(LogIn, '/log_in')
api.add_resource(LogOut, '/log_out')
api.add_resource(ReadLatestMenu, '/read_latest_menu')
api.add_resource(OrderFoodItems, '/order_food_items')
api.add_resource(AddNewItems, '/add_new_items')
api.add_resource(ChcekUserExistsLoggedIn, '/check_user_exists_logged_in')
api.add_resource(AddCompletedTransaction, '/add_completed_transaction')
api.add_resource(ListPreviousTransactions, '/list_previous_transactions')

# api.add_resource(ShowParticularTransaction, '/show_particular_transaction')
# api.add_resource(Delete, '/delete/<id>')


#run flask app
if __name__ == "__main__":
    db.drop_all()
    db.create_all()

    # adding a static chef account at the beginning of the program
    obj = UserInfo(username="chef", password="chef@123", isLoggedIn=False, isChef=True)
    db.session.add(obj)
    db.session.commit()

    # adding a static user account at the beginning of the program
    obj = UserInfo(username="user", password="123", isLoggedIn=False, isChef=False)
    db.session.add(obj)
    db.session.commit()

    # adding default menu at the beginning of the program
    with open('Menu.csv', 'r') as read_obj:
        # pass the file object to reader() to get the reader object
        csv_reader = csv.reader(read_obj)
        # Pass reader object to list() to get a list of lists
        list_of_rows = list(csv_reader)
        for i in range(1, len(list_of_rows)):
            item_no = list_of_rows[i][0]
            half_plate_cost = list_of_rows[i][1]
            full_plate_cost = list_of_rows[i][2]
            obj = FoodMenu(item_no=item_no,
                           half_plate_cost=half_plate_cost, full_plate_cost=full_plate_cost)
            db.session.add(obj)
            db.session.commit()
            # print(f"{list_of_rows[i][0]:^15} {list_of_rows[i][1]:^15} {list_of_rows[i][2]:^15}")

    app.run(port=8000, debug=True)
