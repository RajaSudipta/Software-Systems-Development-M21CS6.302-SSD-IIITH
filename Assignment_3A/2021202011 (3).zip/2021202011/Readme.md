# Assignment 3A - Python Programming 

## while taking input from the user for food, we need to first give how many food items we need to order. Then, for each food item, we need to input 3 parameters food_item_no, no_of_half_plates, no_of_full_plates(eg. 1 2 3)(food_no.1, half_plates=2, full_plates=3) 

## TIP percenrage should be 0% or 10% or 20%, we need to only typr 0 or 10 or 20 

## We need to just a type a number when it will ask for 'How many persons among whom you want to split bill:'

## For LUCKY DRAW if we want to participate we need to type 1, else type 0