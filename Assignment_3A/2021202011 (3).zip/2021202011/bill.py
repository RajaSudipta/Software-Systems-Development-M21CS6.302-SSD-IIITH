import csv
import random

''' function for printing discount pattern '''
def print_discount_pattern():
    print()
    for i in range(5):
        if(i == 0 or i == 4):
            for j in range(30):
                if((j >= 8 and j <= 11) or (j >= 18 and j <= 21)):
                    print("*", end="")
                else:
                    print(" ", end="")
        else:
            for j in range(30):
                if(j == 8 or j == 11 or j == 18 or j == 21):
                    print("|", end="")
                else:
                    print(" ", end="")
        print()
    print()
    print("              {}             ")
    print()
    print("           ________           ")
    print()
    
    # print("****    ****")
    # print("|  |    |  |")
    # print("|  |    |  |")
    # print("|  |    |  |")
    # print("****    ****")

''' function for printing increase pattern '''
def print_increase_pattern():
    print()
    for i in range(5):
        if(i == 0 or i == 4):
            for j in range(30):
                if(j >= 14 and j <= 17):
                    print("*", end="")
                else:
                    print(" ", end="")
        else:
            for j in range(30):
                if(j == 14 or j == 17):
                    print("*", end="")
                else:
                    print(" ", end="")
        print()
    print()
    # print("****")
    # print("*   *")
    # print("*   *")
    # print("*   *")
    # print("*   *")
    # print("****")

def maximum(count1, count2, count3, count4, count5):
    list = [count1, count2, count3, count4, count5]
    res = max(list)
    if(res == count1):
        return 1
    elif(res == count2):
        return 2
    elif(res == count3):
        return 3
    elif(res == count4):
        return 4
    elif(res == count5):
        return 5


''' main function '''
def main():
    # print("Hello World")

    ''' read csv file as a list of lists '''
    with open('Menu.csv', 'r') as read_obj: 
        # pass the file object to reader() to get the reader object
        csv_reader = csv.reader(read_obj)
        # Pass reader object to list() to get a list of lists
        list_of_rows = list(csv_reader)

    # print(list_of_rows)

    # row_number = 2
    # col_number = 1
    # value = list_of_rows[row_number - 1][col_number - 1]
    # print('Value in a cell at 2nd row and 1st column : ', value)

    ''' printing the food menu '''
    print("**********************FOOD MENU*****************************")
    for i in range(len(list_of_rows)):
        print(f"{list_of_rows[i][0]:^15} {list_of_rows[i][1]:^15} {list_of_rows[i][2]:^15}")
    print()

    ''' taking input from user '''
    print("****************************************ORDER PLACE****************************************")
    no_of_items = int(input("Enter number of items you want to order: "))
    print("Input item no, no_of_half_plates, no_of_full_plates space separated " + str(no_of_items) + " times" + "(eg. 1 2 3)")
    # Initialize matrix
    matrix = []
    # For user input
    for i in range(no_of_items):          # A for loop for row entries
        a = []
        ''' for taking input separated by next line  '''
        # for j in range(3):      # A for loop for column entries
        #     a.append(int(input()))
        ''' for taking input separated by space for same row and enter for next row '''
        a = list(map(int, input().split()))
        temp = a[0]
        flag = False
        # checking for duplicate food item_no, in that case merge plates 
        for j in range(len(matrix)):
            if(matrix[j][0] == temp):
                matrix[j][1] += a[1]
                matrix[j][2] += a[2]
                flag = True
                break
        if (flag == False):
            matrix.append(a)
    
    # updating actual no_of_items combining duplicate food items 
    no_of_items = len(matrix)

    print("Printing what you ordered")
    # For printing the matrix
    for i in range(no_of_items):
        for j in range(3):
            print(matrix[i][j], end=" ")
        print()
    print()

    ''' TIP '''
    print("***************************************TIP**********************************************")
    tip = int(input("Enter tip percentage(0, 10%, 20%) type any one of them(only type 0 or 10 or 20): "))
    print()

    ''' Calculating total amount '''
    print("**********************INITIAL BILL*****************************")
    total_amount = 0
    for i in range(no_of_items):
        plate_num = matrix[i][0]
        half_plate_quantity = float(matrix[i][1])
        full_plate_quantity = float(matrix[i][2])
        # print("plate_num: " + str(plate_num))
        # print("half_plate_quantity: " + str(half_plate_quantity))
        # print("full_plate_quantity: " + str(full_plate_quantity))
        for j in range(1, len(list_of_rows)):
            temp = int(list_of_rows[j][0])
            # print(temp)
            if(temp == plate_num):
                half_plate_price = float(list_of_rows[j][1])
                full_plate_price = float(list_of_rows[j][2])
                # print("half_plate_price: " + str(half_plate_price))
                # print("full_plate_price: " + str(full_plate_price))
                total_amount = total_amount + (half_plate_quantity * half_plate_price) + (full_plate_quantity * full_plate_price)
                break
    total_amount_after_tips = total_amount + (total_amount * tip)/100
    print("Total amount to be paid including tip:", end = " ")
    print("{0:.2f}".format(total_amount_after_tips))

    ''' Splitting '''
    heads = int(input("How many persons among whom you want to split bill: "))
    per_head_amount = total_amount_after_tips/heads
    print("Each person has to contribute:", end=" ")
    print("{0:.2f}".format(per_head_amount))
    print()

    ''' LUCKY DRAW '''
    print()
    print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>LUCKY DRAW<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
    print("The restaurant has started a limited time event called TEST YOUR LUCK")
    print("*****************************The outcomes are****************************")
    print("1. 5 % chance to get a 50 % discount off the total bill")
    print("2. 10 % chance to get 25 % discount")
    print("3. 15 % chance to get 10 % discount")
    print("4. 20 % chance to get no discount")
    print("5. 50 % chance that the total amount increases by 20%")
    print("***************************************************************")
    print("Do you people want to participate in this event ?")
    turn = int(input("Enter 1 for 'YES' and 0 for 'NO': "))
    print()
    print("************************LOTTERY RESULT******************************")
    increaseOrDiscount = 0
    if(turn == 1):
        ''' do the lottery '''
        numberList = [1, 2, 3, 4, 5]
        lottery_outcome_list = random.choices(numberList, weights=(5, 10, 15, 20, 50), k=5)
        # print(lottery_outcome_list)
        count1=0
        count2=0
        count3=0
        count4=0
        count5=0
        for i in range(len(lottery_outcome_list)):
            if(lottery_outcome_list[i] == 1):
                count1 = count1 + 1
            if(lottery_outcome_list[i] == 2):
                count2 = count2 + 1
            if(lottery_outcome_list[i] == 3):
                count3 = count3 + 1
            if(lottery_outcome_list[i] == 4):
                count4 = count4 + 1
            if(lottery_outcome_list[i] == 5):
                count5 = count5 + 1
        # print(str(count1) + " " + str(count2) + " " + str(count3) + " " + str(count4) + " " + str(count5))
        lottery_outcome = maximum(count1, count2, count3, count4, count5)
        # print("Lottery outcome is: " + str(lottery_outcome))
        # increaseOrDiscount = 0
        if(lottery_outcome == 1):
            print("You got a 50 % discount off the total bill")
            increaseOrDiscount = (total_amount_after_tips * (-1) *50)/100
            print("discount value/increase:", end=" ")
            print("{0:.2f}".format(increaseOrDiscount))
            print_discount_pattern()
        elif(lottery_outcome == 2):
            print("You got a 25 % discount off the total bill")
            increaseOrDiscount = (total_amount_after_tips * (-1) * 25)/100
            print("discount value/increase:", end=" ")
            print("{0:.2f}".format(increaseOrDiscount))
            print_discount_pattern()
        elif(lottery_outcome == 3):
            print("You got a 10 % discount off the total bill")
            increaseOrDiscount = (total_amount_after_tips * (-1) * 10)/100
            print("discount value/increase:", end=" ")
            print("{0:.2f}".format(increaseOrDiscount))
            print_discount_pattern()
        elif(lottery_outcome == 4):
            print("Sorry!! You got no discount off the total bill")
            increaseOrDiscount = 0
            print("discount value/increase:", end=" ")
            print("{0:.2f}".format(increaseOrDiscount))
            print_increase_pattern()
            # print_discount_pattern()
        else:
            print("Sorry!! You have to pay an additional 20% on the total bill amount")
            increaseOrDiscount = (total_amount_after_tips * 20)/100
            print("discount value/increase:", end=" ")
            print("{0:.2f}".format(increaseOrDiscount))
            print_increase_pattern()
            # print_discount_pattern()
    print()
        # total_amount = 0
        # for i in range(no_of_items):
        #     plate_num = matrix[i][0]
        #     half_plate_quantity = float(matrix[i][1])
        #     full_plate_quantity = float(matrix[i][2])
        #     total_quantity = half_plate_quantity + full_plate_quantity
        #     # print("plate_num: " + str(plate_num))
        #     # print("half_plate_quantity: " + str(half_plate_quantity))
        #     # print("full_plate_quantity: " + str(full_plate_quantity))
        #     for j in range(1, len(list_of_rows)):
        #         temp = int(list_of_rows[j][0])
        #         # print(temp)
        #         if(temp == plate_num):
        #             half_plate_price = float(list_of_rows[j][1])
        #             full_plate_price = float(list_of_rows[j][2])
        #             # print("half_plate_price: " + str(half_plate_price))
        #             # print("full_plate_price: " + str(full_plate_price))
        #             curr_item_total_price = (half_plate_quantity * half_plate_price) + (full_plate_quantity * full_plate_price)
        #             total_amount = total_amount + curr_item_total_price
        #             print("Item " + str(plate_num) +
        #                   "[" + str(total_quantity) + "]:", end=" ")
        #             print("{0:.2f}".format(curr_item_total_price))
        #             break
        # print("Total:", end=" ")
        # print("{0:.2f}".format(total_amount))
        # print("Tip percentage: " + str(tip) + "%")
        # print("Discount/Increase:", end=" ")
        # print("{0:.2f}".format(increaseOrDiscount))
        # updated_total_amount = total_amount + (total_amount * tip)/100 + increaseOrDiscount
        # print("Final Total:", end=" ")
        # print("{0:.2f}".format(updated_total_amount))
        # updated_per_head_amount = updated_total_amount/heads
        # print("Each person has to contribute:", end=" ")
        # print("{0:.2f}".format(updated_per_head_amount))

    # else:
    #     print("Lottery not played")

    ''' Calculating final bill including tip and lottery increase/discount '''
    print()
    print("*********************FINAL BILL*********************")
    total_amount = 0
    for i in range(no_of_items):
        plate_num = matrix[i][0]
        half_plate_quantity = float(matrix[i][1])
        full_plate_quantity = float(matrix[i][2])
        total_quantity = half_plate_quantity + full_plate_quantity
        # print("plate_num: " + str(plate_num))
        # print("half_plate_quantity: " + str(half_plate_quantity))
        # print("full_plate_quantity: " + str(full_plate_quantity))
        for j in range(1, len(list_of_rows)):
            temp = int(list_of_rows[j][0])
            # print(temp)
            if(temp == plate_num):
                half_plate_price = float(list_of_rows[j][1])
                full_plate_price = float(list_of_rows[j][2])
                # print("half_plate_price: " + str(half_plate_price))
                # print("full_plate_price: " + str(full_plate_price))
                half_plate_total_price = half_plate_quantity * half_plate_price
                full_plate_total_price = full_plate_quantity * full_plate_price
                curr_item_total_price = (
                    half_plate_quantity * half_plate_price) + (full_plate_quantity * full_plate_price)
                total_amount = total_amount + curr_item_total_price
                print("Item " + str(plate_num) + "[Half]"
                    "[" + str(int(half_plate_quantity)) + "]:", end=" ")
                print("{0:.2f}".format(half_plate_total_price))
                print("Item " + str(plate_num) + "[Full]"
                    "[" + str(int(full_plate_quantity)) + "]:", end=" ")
                print("{0:.2f}".format(full_plate_total_price))
                # print("Item " + str(plate_num) +
                #       "[" + str(int(total_quantity)) + "]:", end=" ")
                # print("{0:.2f}".format(curr_item_total_price))
                break
    print("Total:", end=" ")
    print("{0:.2f}".format(total_amount))
    print("Tip percentage: " + str(tip) + "%")
    print("Discount/Increase:", end=" ")
    print("{0:.2f}".format(increaseOrDiscount))
    updated_total_amount = total_amount + \
        (total_amount * tip)/100 + increaseOrDiscount
    print("Final Total:", end=" ")
    print("{0:.2f}".format(updated_total_amount))
    updated_per_head_amount = updated_total_amount/heads
    print("Each person has to contribute:", end=" ")
    print("{0:.2f}".format(updated_per_head_amount))
    print("****************************************************")

if __name__ == "__main__":
    main()




