
1. 'index.html' is the 'Home' Page and 'index2.html' is the 'About Us' Page
2. If we click in 'Home' in Nav Bar it will load the 'Home' page in the same tab.
3. If we click in 'About Us' in Nav Bar it will load the 'About Us' page in new tab.