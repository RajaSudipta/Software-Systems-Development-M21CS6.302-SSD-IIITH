# SSD Lab 11
## python server.py <PORT>
## python client.py <PORT>
## If a client wants to get quit, it should type 'quit'