# SSD Lab Activity 8

## q1.py , q2.py, q3.py input has been taken by command line arguements

## q1.py
### sample i/p: python q1.py "BruceWayneIsBatman Iam"
### o/p:  bruce wayne is batman  iam

## q2.py
### sample i/p: python q2.py 1001
### o/p:  TRUE

## q3.py
### sample i/p: python q3.py "34 45 65 11 34"
### o/p:  [ 11, 34, 34, 45, 65]

## q4.py
### First we defined a base class 'Car' and created method 'run'
### Next, The class Volkswagen inherits the base class Car and created method 'runningSpeed'
### Next, The class Audi inherits another child class Volkswagen and created method 'looking'
### Hence due to inheritence, class Volkswagen has methods 'run' and 'runningSpeed'. 
### class Audi has methods 'run' and 'runningSpeed' and 'looking'.
### Next, we created an object of Audi class and invoked the parent methods 'run', 'runningSpeed' and invoked its own method 'looking'

