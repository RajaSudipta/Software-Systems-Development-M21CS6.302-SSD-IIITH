import sys

def BinaryToDecimal(binary):
    decimal = 0
    for i in binary:
        decimal = decimal*2 + int(i)
    return decimal

def palindrome(n):
    reverse = 0
    while(n > 0):
        rem = n % 10
        reverse = reverse*10 + rem
        n = n//10
    return reverse


def main():
    # Taking binary input
    # binary = input("Enter a binary number:")
    n = len(sys.argv)
    
    if(n == 1):
        print("TRUE")
    else:
        binary = sys.argv[1]
        # print(binary)
        # Calling the function
        decimal = BinaryToDecimal(binary)
        # print(decimal)
        res = palindrome(decimal)
        if(res == decimal):
            print("TRUE")
        else:
            print("FALSE")
    

if __name__ == "__main__":
    main()



