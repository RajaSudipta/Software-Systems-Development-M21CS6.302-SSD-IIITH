import sys

def main():
    n = len(sys.argv)
    if(n == 1):
        list = []
        print(list)
    else:
        string = sys.argv[1]
        ss = string.split()
        # print(ss)
        sorted_list = sorted(ss, key=lambda x: float(x))
        # print(sorted_list)
        list = []
        for i in range(len(sorted_list)):
            try:
                list.append(int(sorted_list[i]))
            except:
                list.append(float(sorted_list[i]))
        print(list)


if __name__ == "__main__":
    main()
