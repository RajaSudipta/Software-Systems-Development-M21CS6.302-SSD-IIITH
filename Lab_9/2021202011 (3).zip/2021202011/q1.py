import re
import sys

def main():
    n = len(sys.argv)
    if(n == 1):
        print("")
    else:
        string = sys.argv[1]
        tokens = re.findall('[A-Z][^A-Z]*', string)
        # print(tokens)
        # for string with all small letters
        if(len(tokens) > 0):
            x = string.split(tokens[0])
            # print(x)
            x = x[0]
            # print(x)
            list = []
            list.append(x.lower())
            for i in tokens:
                list.append(" ")
                list.append(i.lower())
            print("".join(list))
            
        else:
            print(str)

# Driver program
if __name__ == "__main__":
    main()



