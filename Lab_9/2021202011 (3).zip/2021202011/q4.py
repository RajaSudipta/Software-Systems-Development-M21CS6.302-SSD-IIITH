class Car:
    def run(self):
        print("**********Parent Class**********")
        print("Cars running")

#The child class Volkswagen inherits the base class Car
class Volkswagen(Car):
    def runningSpeed(self):
        print("**********Child of Parent Class**********")
        print("Volkswagen running at 200 kmph")

#The child class Audi inherits another child class Volkswagen
class Audi(Volkswagen):
    def looking(self):
        print("**********Grand Child of Parent Class**********")
        print("Audi is looking beautiful and running at 250 kmph")


def main():
    obj = Audi()
    obj.run()
    obj.runningSpeed()
    obj.looking()

if __name__ == "__main__":
    main()


