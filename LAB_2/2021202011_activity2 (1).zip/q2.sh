#!/bin/bash
#Assuming that hamlet.txt is in the same directory

echo -e "1. Display all the lines in which the word “is” occurs:"
grep -w "is" $1

echo -e "\n2. Display the middle 10 lines of the file:"
lines=$(awk '{x++} END {print x}' $1)
echo "Number of lines: $lines"
d=2

if [ `expr $lines % 2` == 0 ]
then
    echo "$lines is even"
    temp=$(($lines-10))
    temp1=$((temp / d+10))
    # echo $temp
    # echo $temp1
    echo -e "Only one possibility:\n"
    head -n $temp1 hamlet.txt | tail -10 
else
    echo "$lines is odd"
    temp=$(($lines-10))
    temp1=$((temp / d+10))
    temp2=$(($temp1+1))
    # echo $temp
    # echo $temp1
    # echo $temp2
    echo -e "\nTwo possibilities:"
    echo -e "\n Possibility 1"
    head -n $temp1 hamlet.txt | tail -10
    echo -e "\n Possibility 2"
    head -n $temp2 hamlet.txt | tail -10
fi

# echo -e "\nTwo possibilities"
# echo -e "\n Line 13 to 22"
# head -n 22 hamlet.txt | tail -10
# echo -e "\n Line 14 to 23"
# head -n 23 hamlet.txt | tail -10

echo -e "\n3. Print the third and the fifth words of every row from the file using a single command:"
awk '{print $3,$5}' $1