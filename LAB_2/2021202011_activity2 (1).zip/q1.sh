#!/bin/bash
num=$#
if [ $# -eq 3 ] 
then
    res=`echo "$1+$2-$3" | bc`
    echo -n "$1 + $2 - $3 = "
    echo $res
else
    echo "Provide Exactly 3 arguements"
fi