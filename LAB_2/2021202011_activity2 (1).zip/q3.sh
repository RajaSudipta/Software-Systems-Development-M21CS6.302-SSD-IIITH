#!/bin/bash
# listing deatils then matching execution for group then printing the 9th column for file names
ls -l | grep "^-[-rwx][-rwx][-rwx][-rwx][-rwx][x]" | awk '{print $9}'