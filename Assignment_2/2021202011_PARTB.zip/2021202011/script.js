const paragraph = document.getElementById("edit");
const edit_button = document.getElementById("edit-button");
const end_button = document.getElementById("end-editing");

edit_button.addEventListener("click", function () {
    paragraph.contentEditable = true;
    paragraph.style.backgroundColor = "#dddbdb";
});

end_button.addEventListener("click", function () {
    paragraph.contentEditable = false;
    paragraph.style.backgroundColor = "#FFFFFF";
})

/*  */
const paragraph2 = document.getElementById("edit_pcw");
const edit_button2 = document.getElementById("edit-button_pcw");
const end_button2 = document.getElementById("end-editing_pcw");

edit_button2.addEventListener("click", function () {
    paragraph2.contentEditable = true;
    paragraph2.style.backgroundColor = "#dddbdb";
});

end_button2.addEventListener("click", function () {
    paragraph2.contentEditable = false;
    paragraph2.style.backgroundColor = "#FFFFFF";
})

/*  */
const paragraph3 = document.getElementById("edit_journal");
const edit_button3 = document.getElementById("edit-button_journal");
const end_button3 = document.getElementById("end-editing_journal");

edit_button3.addEventListener("click", function () {
    paragraph3.contentEditable = true;
    paragraph3.style.backgroundColor = "#dddbdb";
});

end_button3.addEventListener("click", function () {
    paragraph3.contentEditable = false;
    paragraph3.style.backgroundColor = "#FFFFFF";
})

/*  */
const paragraph4 = document.getElementById("edit_magazine");
const edit_button4 = document.getElementById("edit-button_magazine");
const end_button4 = document.getElementById("end-editing_magazine");

edit_button4.addEventListener("click", function () {
    paragraph4.contentEditable = true;
    paragraph4.style.backgroundColor = "#dddbdb";
});

end_button4.addEventListener("click", function () {
    paragraph4.contentEditable = false;
    paragraph4.style.backgroundColor = "#FFFFFF";
})

/*  */
const paragraph5 = document.getElementById("edit_book");
const edit_button5 = document.getElementById("edit-button_book");
const end_button5 = document.getElementById("end-editing_book");

edit_button5.addEventListener("click", function () {
    paragraph5.contentEditable = true;
    paragraph5.style.backgroundColor = "#dddbdb";
});

end_button5.addEventListener("click", function () {
    paragraph5.contentEditable = false;
    paragraph5.style.backgroundColor = "#FFFFFF";
})

/*  */
const paragraph6 = document.getElementById("edit_editorship");
const edit_button6 = document.getElementById("edit-button_editorship");
const end_button6 = document.getElementById("end-editing_editorship");

edit_button6.addEventListener("click", function () {
    paragraph6.contentEditable = true;
    paragraph6.style.backgroundColor = "#dddbdb";
});

end_button6.addEventListener("click", function () {
    paragraph6.contentEditable = false;
    paragraph6.style.backgroundColor = "#FFFFFF";
})

/*  */
const paragraph7 = document.getElementById("edit_patents");
const edit_button7 = document.getElementById("edit-button_patents");
const end_button7 = document.getElementById("end-editing_patents");

edit_button7.addEventListener("click", function () {
    paragraph7.contentEditable = true;
    paragraph7.style.backgroundColor = "#dddbdb";
});

end_button7.addEventListener("click", function () {
    paragraph7.contentEditable = false;
    paragraph7.style.backgroundColor = "#FFFFFF";
})