# Assumptions for q1.sh
### I have used substring to trim out the '/' from the folder name Example. ('SSD_Lab_1/' -> 'SSD_Lab_1').

# Assumptions for q2.sh
### Temporary Files: 'temp.txt', 'temp_without_pinctuation.txt' (Generated while running program).
### We need to place the 'input.txt' and 'output.txt' these two files in the same directory. Now, I am converting all the words of the words of the 'input.txt' into lowercase and placing it in the 'temp.txt'. After that, removing punctuation and keeping it in 'temp_without_pinctuation.txt'. Now from 'temp.txt' I am matching the words which are ending with 'ing' and appending the strings in the 'output.txt'.
### After the program execution is complete the temporary files are deleted.

# Assumptions for q3.sh
### Temporary Files : 'shellCommands.txt', 'shellCommandsLower.txt', 'shellCommandsFound.txt', 'shellCommandsSorted.txt' (Generated while running program).
### First I am storing all bash commands in file shellCommands.txt
### Then converting all the bash commands into lower case and storing them in another file shellCommandsLower.txt
### Coverting the input string into lower case.
### Calling the function permutations to generate all possible permutations of the input word and if it matches with the command present in shellCommandsLower.txt it appends in file shellCommandsFound.txt
### Sorting the file shellCommandsFound and keeping that in shellCommandsSorted.txt
### After the program execution is complete the temporary files are deleted.

# Assumptions for q4.sh
### I have assumed that numbers will range from [1 - 3999]..
### While giving roman inputs as arguements It should be in capital letters ('I', 'V', 'X', 'L', 'C', 'D', 'M').
### If you pass more than 2 arguemnts or no arguements it wll show "Wrong Input".

# Assumptions for q5.sh
### Kept the output silent while zipping files using zip command.
