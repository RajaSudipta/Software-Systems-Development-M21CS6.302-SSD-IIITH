#!/bin/bash

function intToRoman()
{
    thousands=("" "M" "MM" "MMM")
    hundreds=("" "C" "CC" "CCC" "CD" "D" "DC" "DCC" "DCCC" "CM")
    tens=("" "X" "XX" "XXX" "XL" "L" "LX" "LXX" "LXXX" "XC")
    units=("" "I" "II" "III" "IV" "V" "VI" "VII" "VIII" "IX")

    th=$(($1/1000))
    # echo $th

    hu1=$(($1%1000))
    hu=$(($hu1/100))
    # echo $hu

    te1=$(($1%100))
    te=$(($te1/10))
    # echo $te

    un=$(($1%10))
    # echo $un


    a="${thousands[th]}"
    b="${hundreds[hu]}"
    c="${tens[te]}"
    d="${units[un]}"

    # echo $a
    # echo $b
    # echo $c
    # echo $d

    # res=`echo "$a+$b+$c+$d" | bc`
    # res=`expr "$a" + "$b" + "$c" + "$d"`
    # res=$(echo "$a+$b+$c+$d" | bc)
    # res=$(($a+$b+$c+$d))

    res="${a}${b}${c}${d}"
    echo $res
}

function romanToInt()
{

    declare -A map=( ["I"]=1 ["V"]=5 ["X"]=10 ["L"]=50 ["C"]=100 ["D"]=500 ["M"]=1000)

    res=0

    romanString=$1
    
    # string indexing from 1 to n
    # while (( ++i <= ${#romanString} ))
    for (( i=1; i<=${#romanString}; ++i ))
    do
        # # char=$(expr substr "$MyString" $i 1)
        # # echo "$char"
        # char=$(expr substr "$romanString" $i 1)
        # # echo "character: $char"
        # temp=${map[$char]}
        # # echo "value: $temp"
        # res=$(($res+$temp))
        # # echo "sum: $res"

        if(( $i==1 ))
        then
            char=$(expr substr "$romanString" $i 1)
            temp="${map[$char]}"
            res=$(($res+$temp))
        else
            j=$(($i-1))
            # echo "i: $i, j: $j"
            char1=$(expr substr "$romanString" $i 1)
            temp1="${map[$char1]}"
            char2=$(expr substr "$romanString" $j 1)
            # echo "char1: $char1, char2: $char2"
            temp2="${map[$char2]}"

            if(( $temp1>$temp2 ))
            then
                tt=$(($temp2*2))
                res=$(($res+$temp1))
                res=$(($res-$tt))
            else
                res=$(($res+$temp1))
            fi
        fi
    done

    echo $res
}

# only 1 arguement
if [ $# -eq 1 ]
then
    res=$(intToRoman $1)
    echo $res
# 2 arguements
elif [ $# -eq 2 ]
then
    sum=$(($1+$2))
    if(($sum>0))
    then
        roman=$(intToRoman $sum)
        echo $roman
    else
        int1=$(romanToInt $1)
        # echo $int1
        int2=$(romanToInt $2)
        # echo $int2
        res=$(($int1+$int2))
        echo $res
    fi
else
    echo "Provide correct number of arguements"
fi