#!/bin/bash
# Generating all permutations of the string
permutations() 
{
  local it
  local str="$1"
  local output="$2"
  
  a='^'
  b='$'

  [[ "$str" == "" ]] && if grep -q "${a}${output}${b}" shellCommandsLower.txt
    then
        echo "${output}" >> shellCommandsFound.txt
    fi && return
  for (( it=0; it<${#str}; it++ ))
  do
    permutations "${str:0:it}${str:it+1}" "$output${str:it:1}"
  done
}

# Removing the file shellCommands.txt if already exists
rm -f -- shellCommands.txt

# Creating the file shellCommands.txt 
touch shellCommands.txt
chmod 777 shellCommands.txt

# printing all the bash commands in shellCommands.txt
compgen -c > shellCommands.txt

# Coverting all the bash commands into lower case and printing them in shellCommandsLower.txt
sed 's/.*/\L&/g' < shellCommands.txt | awk '{print}' > shellCommandsLower.txt

# cat shellCommandsLower.txt

# Removing and Creating the file shellCommandsFound.txt
rm -f -- shellCommandsFound.txt
touch shellCommandsFound.txt
chmod 777 shellCommandsFound.txt

# Converting the input string into lowercase
input_str=${1,,}

# Calling the function permutations to generate all possible permutations of the input word and if it matches with the command present in shellCommandsLower.txt it appends in file shellCommandsFound.txt
permutations $input_str

# Removing and Creating the file shellCommandsFound.txt
rm -f -- shellCommandsSorted.txt
touch shellCommandsSorted.txt
chmod 777 shellCommandsSorted.txt

# Sorting the file shellCommandsFound and keeping that in shellCommandsSorted.txt
sort shellCommandsFound.txt > shellCommandsSorted.txt

# cat -t shellCommandsSorted.txt

# coutputing no of characters in the file shellCommandsSorted.txt
var=`wc -m shellCommandsSorted.txt | awk '{print $1}'`

# echo $var

# If character count>0 then print YES followed by found commands else print NO
if (($var>0))
then    
    echo -n "YES" 
    echo -ne '\t'
    LINES=$(cat shellCommandsSorted.txt)
    i=0
    for LINE in $LINES
    do
      if (($i==0))
      then
        echo -n "$LINE"
      else
        echo -ne '\t'
        echo -n "$LINE"
      fi
      i=$((i+1))
    done
else
    echo -n "NO"
fi

# Deleting the temporary files
rm -f -- shellCommands.txt
rm -f -- shellCommandsLower.txt
rm -f -- shellCommandsFound.txt
rm -f -- shellCommandsSorted.txt

