#!/bin/bash

# Deleting and Creating the temp.txt
rm -f -- temp.txt
touch temp.txt
chmod 777 temp.txt

sed 's/.*/\L&/g' < $1 | awk '{print}' > temp.txt
cat temp.txt | tr -d '[:punct:]' > temp_without_pinctuation.txt
awk '{for(i=1;i<=NF;i++) {print $i}}' temp_without_pinctuation.txt | grep "ing$" > $2

# Deleting the temporary files
rm -f -- temp.txt
rm -f -- temp_without_pinctuation.txt

