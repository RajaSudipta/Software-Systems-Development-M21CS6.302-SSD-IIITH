#!/bin/bash
du -sh */ | sort -hr | awk -F\. '{print $0}' | awk '{print substr($2, 1, length($2)-1), "\t", $1}'