#!/bin/bash
# deleting the dire if already exists
rm -rf temp_activity

# making the directory
mkdir temp_activity

# going inside the directory
cd temp_activity

# creating temp(1 to 50).txt
touch temp{1..50}.txt

# changing extenson of 1st 25 files to .md
for file in temp{1..25}.txt
do
    mv "$file" "${file%.txt}.md"
done

# changing files name to temp_modified
for file in temp{1..50}.*
do mv "$file" "${file%.*}_modified.${file##*.}"
done

# Among these files with extension belonging to txt and md, ZIP all the .txt files ONLY and name the ZIP file as txt_compressed.zip
find . | egrep "\.(txt)$" | zip -q@ txt_compressed.zip
